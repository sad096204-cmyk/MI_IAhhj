# MI_IA v0.1 (núcleo) — SIN COMPILAR NI PROBAR
Abrir en Android Studio (Koala+) y ejecutar. Hecho: Hey Gri->voz, burbuja, memoria SQLite, TTS, interfaz de módulos.
Pendiente: LLM offline, hotword real (Vosk/openWakeWord), muñeco/animaciones, gestor de módulos, backup, online, seguridad, sorpresa.
