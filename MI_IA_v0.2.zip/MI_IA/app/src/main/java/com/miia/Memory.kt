package com.miia
import android.content.*; import android.database.sqlite.*
class Memory(c: Context) : SQLiteOpenHelper(c, "miia.db", null, 1) {
  override fun onCreate(d: SQLiteDatabase) {
    d.execSQL("CREATE TABLE msgs(id INTEGER PRIMARY KEY, who TEXT, txt TEXT, ts INTEGER)")
    d.execSQL("CREATE TABLE prefs(k TEXT PRIMARY KEY, v TEXT)") }
  override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {} // nunca borrar datos al actualizar
  fun log(who: String, t: String) { writableDatabase.insert("msgs", null, ContentValues().apply { put("who", who); put("txt", t); put("ts", System.currentTimeMillis()) }) }
  fun put(k: String, v: String) { writableDatabase.insertWithOnConflict("prefs", null, ContentValues().apply { put("k", k); put("v", v) }, SQLiteDatabase.CONFLICT_REPLACE) }
  fun get(k: String): String? = readableDatabase.rawQuery("SELECT v FROM prefs WHERE k=?", arrayOf(k)).use { if (it.moveToFirst()) it.getString(0) else null }
  fun lastLine(): String? = readableDatabase.rawQuery("SELECT txt FROM msgs WHERE who='yo' ORDER BY id DESC LIMIT 1 OFFSET 1", null).use { if (it.moveToFirst()) it.getString(0) else null }
}
