package com.miia
import android.app.Service; import android.content.Intent; import android.graphics.*; import android.graphics.drawable.GradientDrawable
import android.view.*; import android.widget.*
class BubbleService : Service() {
  private lateinit var wm: WindowManager; private lateinit var root: LinearLayout; private lateinit var mem: Memory
  override fun onBind(i: Intent?) = null
  override fun onCreate() {
    mem = Memory(this); wm = getSystemService(WINDOW_SERVICE) as WindowManager
    val face = TextView(this).apply { text = "🤖"; textSize = 30f; gravity = Gravity.CENTER
      background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#2979FF")) }; layoutParams = LinearLayout.LayoutParams(150, 150) }
    val out = TextView(this).apply { setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#CC000000")); setPadding(16, 8, 16, 8); visibility = View.GONE }
    val inp = EditText(this).apply { hint = "Escribe…"; setHintTextColor(Color.GRAY); setTextColor(Color.WHITE) }
    val send = Button(this).apply { text = "➤" }; val mic = Button(this).apply { text = "🎤" }
    val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; visibility = View.GONE; setBackgroundColor(Color.parseColor("#CC000000"))
      addView(inp, LinearLayout.LayoutParams(450, -2)); addView(send); addView(mic) }
    send.setOnClickListener { val q = inp.text.toString(); if (q.isNotBlank()) { out.text = Brain.reply(mem, q); out.visibility = View.VISIBLE; inp.setText("") } }
    mic.setOnClickListener { startService(Intent(this, WakeService::class.java).setAction("LISTEN")) }
    root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; addView(face); addView(out); addView(row) }
    val lp = WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
    var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
    face.setOnTouchListener { _, e -> when (e.action) {
      MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
      MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - dx) > 10 || Math.abs(e.rawY - dy) > 10) moved = true; lp.x = sx + (e.rawX - dx).toInt(); lp.y = sy + (e.rawY - dy).toInt(); wm.updateViewLayout(root, lp) }
      MotionEvent.ACTION_UP -> if (!moved) { val open = row.visibility == View.GONE; row.visibility = if (open) View.VISIBLE else View.GONE
        lp.flags = if (open) WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS else WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        if (!open) out.visibility = View.GONE; wm.updateViewLayout(root, lp) } }; true }
    wm.addView(root, lp)
  }
  override fun onDestroy() { wm.removeView(root) }
}
