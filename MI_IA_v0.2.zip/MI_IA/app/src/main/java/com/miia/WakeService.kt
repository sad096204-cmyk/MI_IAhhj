package com.miia
import android.app.*; import android.content.*; import android.content.pm.ServiceInfo; import android.os.*
import android.speech.*; import android.speech.tts.*; import java.util.*
class WakeService : Service(), RecognitionListener {
  private lateinit var sr: SpeechRecognizer; private lateinit var tts: TextToSpeech; private lateinit var mem: Memory
  private val h = Handler(Looper.getMainLooper()); private var command = false; private var ttsOk = false
  override fun onBind(i: Intent?) = null
  override fun onCreate() {
    mem = Memory(this)
    val ch = "miia"; getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel(ch, "MI_IA", NotificationManager.IMPORTANCE_LOW))
    val n = Notification.Builder(this, ch).setContentTitle("MI_IA escuchando «Hey Gri»").setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
    if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, n)
    tts = TextToSpeech(this) { ttsOk = it == TextToSpeech.SUCCESS; if (ttsOk) tts.language = Locale("es", "ES") }
    tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
      override fun onStart(u: String?) {}; override fun onError(u: String?) { h.post { listen() } }
      override fun onDone(u: String?) { h.post { if (u == "ask") { command = true } ; listen() } } })
    sr = SpeechRecognizer.createSpeechRecognizer(this); sr.setRecognitionListener(this); listen()
  }
  override fun onStartCommand(i: Intent?, f: Int, s: Int): Int { if (i?.action == "LISTEN") { command = true; listen() }; return START_STICKY }
  private fun listen() {
    sr.cancel()
    sr.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES"); putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true) })
  }
  fun say(t: String, id: String = "say") { sr.cancel(); if (ttsOk) tts.speak(t, TextToSpeech.QUEUE_FLUSH, null, id) else listen() }
  private val wake = Regex("(hey|ey|jei|ei|hay)\\s*(gri|gui|gry|gree|grey|cri)")
  override fun onResults(r: Bundle) {
    val t = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.lowercase() ?: ""
    if (command) { command = false; if (t.isNotBlank()) say(Brain.reply(mem, t)) else listen() }
    else if (wake.containsMatchIn(t)) {
      val rest = t.substring(wake.find(t)!!.range.last + 1).trim()
      if (rest.isNotEmpty()) say(Brain.reply(mem, rest)) else say("¡Hola! Te escucho, dime.", "ask")
    } else listen()
  }
  override fun onError(e: Int) { h.postDelayed({ listen() }, if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 300) }
  override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(v: Float) {}
  override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}
  override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, b: Bundle?) {}
  override fun onDestroy() { sr.destroy(); tts.shutdown() }
}
