package com.miia
import java.text.SimpleDateFormat; import java.util.*
/** Punto de extensión: cada módulo se registra sin recompilar el núcleo. */
interface MiModule { val id: String; var enabled: Boolean; fun handles(q: String): Boolean; fun answer(q: String): String }
object Brain {
  val modules = mutableListOf<MiModule>()
  fun reply(mem: Memory, q: String): String {
    val t = q.lowercase().trim(); mem.log("yo", q)
    val a = modules.firstOrNull { it.enabled && it.handles(t) }?.answer(t) ?: when {
      "hora" in t -> "Son las " + SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
      t.startsWith("recuerda que ") -> { mem.put("nota", t.removePrefix("recuerda que ")); "Anotado, lo recordaré." }
      "qué te dije" in t || "que te dije" in t -> mem.get("nota")?.let { "Me dijiste que $it" } ?: "Aún no me has pedido recordar nada."
      "cómo te llamas" in t || "como te llamas" in t -> "Soy MI_IA. Puedes llamarme diciendo: Hey Gri."
      else -> "Todavía mi cerebro offline es básico: no tengo un modelo de lenguaje instalado, así que no sé responder a eso."
    }
    mem.log("ia", a); return a
  }
}
