package com.miia
import android.Manifest; import android.app.Activity; import android.content.Intent; import android.net.Uri; import android.os.*; import android.provider.Settings; import android.widget.*
class MainActivity : Activity() {
  override fun onCreate(b: Bundle?) { super.onCreate(b)
    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS), 1)
    val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
    fun btn(t: String, f: () -> Unit) = l.addView(Button(this).apply { text = t; setOnClickListener { f() } })
    btn("Permitir burbuja sobre otras apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
    btn("Activar burbuja") { if (Settings.canDrawOverlays(this)) startService(Intent(this, BubbleService::class.java)) else toast("Falta el permiso de superposición") }
    btn("Activar «Hey Gri» (voz)") { if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == 0) startForegroundService(Intent(this, WakeService::class.java)) else toast("Falta permiso de micrófono") }
    btn("Desactivar «Hey Gri»") { stopService(Intent(this, WakeService::class.java)) }
    setContentView(l) }
  private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
